import mongoose from 'mongoose';

const ejemploSchema = new mongoose.Schema({
    nombre:{
        type: String,
        required: true
    },
    apellido:{
        type: String,
        required: true
    },
    edad:{
        type: String,
        required: true
    },
    contacto:{
        type: [String],
        required: true
    },
});

const Ejemplos = mongoose.model('Ejemplos', ejemploSchema);
export default Ejemplos;