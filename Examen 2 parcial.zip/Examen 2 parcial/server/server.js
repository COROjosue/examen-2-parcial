import express from 'express';
import cors from 'cors';
import ejemplo from '../routes/ejemplos.routes.js';
import indexRoutes from '../routes/index.routes.js';
import  db from '../db/cnn_mongodb.js';

{
    export default class Server{
    constructor(){
        this.app = express();
        this.port = process.env.PORT || 3000;
        this.generalRoute = '/api/';

        this.conectarDBMongo();

        this.middlewares();

        this.routes();
    }

    async conectarDBMongo(){
        if(db.isconnec){
            await db.conectarDBMongo();
        }
    }

    middlewares (){
        this.app.use(cors());

        this.app.use(express.json());

        this.app.use(express.static('public'));
    }

    routes(){
        //localhost:000/miapi/ejemplo
        this.app.use(this.generalRoute, require('../routes/index.routes.js'));
        this.app.use('**',(req, res) =>{
            res.status(404).json({
                msg: 'Ruta no encontrada'
            });
        })
        }

    }

    listen() 
        this.app.listen(this.port, () => {
            console.log('servidor corriendo en puerto', '${this.port}',yellow);
        });
    
}