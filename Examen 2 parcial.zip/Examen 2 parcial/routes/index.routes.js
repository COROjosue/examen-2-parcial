import ejemplos from './ejemplos.routes.js';
import {router} from 'express';
const indexRoutes = router();

indexRoutes.use('/ejemplos',ejemplos);


export default indexRoutes;