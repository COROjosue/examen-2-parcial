import{router} from 'express';
import{ 
    getAllEjemplos,
    getEjemploById,
    postEjemplo,
    putEjemplo,
    deleteEjemplo 


} from '../controllers/ejemplos.controllers.js';
const ejemplos = Router ();

ejemplos.get('/', getAllEjemplos);

ejemplos.get('/:id', getEjemploById);

ejemplos.put('/',putEjemplo);

ejemplos.post('/',postEjemplo);

ejemplos.delete('/:id',deleteEjemplo);

export default ejemplos;